// Funkcja do rozwijania i zwijania nawigacji na urz�dzeniach mobilnych
function toggleMenu() {
    var navbar = document.querySelector('.navbar');
    navbar.classList.toggle('responsive');
}
